# Start here — Four-book numerology methodology audit

Source revision: 151f48c9ce614c92f6d7d8081a4169a405f183f6
Repository: u-dont-existDOTcom/humandesign
Branch: research/six-rule-life-timing-20261001

Open **NUMEROLOGY_AUDIT_READER.html** for the integrated offline reader, or **SUMMARY.html** for the short conclusions. No internet, login, scripts, fonts or raw book downloads are needed to read these derived reports.

The canonical main audit is reference/research/NUMEROLOGY_BOOK_AUDIT_V2_20261004.md. The effective registry is reference/research/numerology_method_registry_v2_1_20261004.json; the original V2 registry and source freeze remain intact as its baseline. Full per-author specifications, the mandatory reconciliation, ambiguities, exact source freeze, arithmetic fixtures, independent closeout review and post-freeze empirical design are under reference/research/numerology_v2_20261004/.

The inherited V1 audit and registry are included because Cheiro V2 and the comparison depend on them. The policy and bounded historical annotations are included. Raw copyrighted books, complete transcripts, credentials, private reviewer logs and new participant data are not included. Original book hashes and page locators identify the supplied sources; this packet is an audit, not a substitute facsimile.

The source arithmetic and control regression tests run with Python 3.10 or later and the standard library:

```sh
python3 -m unittest discover -s tests -p 'test_numerology_book_*.py' -v
```

Run that command in the extracted packet directory. The full audit acceptance command additionally needs the actual Git checkout, task lock and history; an extracted ZIP is not a Git repository. Its exact-head acceptance result is included under verification/ when supplied at build time.

The source freeze does not make unresolved author instructions single-valued. AUDIT_ERRATA_V2_1_20261004.md controls its enumerated corrections, then SOURCE_RECONCILIATION.md. The V2.1 registry is the effective entry point; original V2 bytes are historical and immutable. No author mixing, outcome-selected branch, retrospective rescue, empirical superiority or causal name-change claim is authorized. The proposed study has not launched; its separate operational prerequisites are listed explicitly.

PACKET_MANIFEST.json gives SHA-256 hashes of the payload files. It does not include itself. The separately recorded ZIP hash verifies the outer delivery object.
