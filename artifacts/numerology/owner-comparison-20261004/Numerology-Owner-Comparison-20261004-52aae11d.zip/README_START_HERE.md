# Numerology owner-history comparison

Source revision: 52aae11da1b49042ba4f2480cabd893b1406aff4

Open OWNER_COMPARISON_READER.html for the report, coverage ledger and independent check. The JSON files under experiments/numerology/owner_comparison_20261004/ contain exact core calculations, event intervals,36coarse adapters, separate post-result hypotheses and transparency controls. The calculation companions and reconciliation script reproduce these outputs.

This is a retrospective DEVELOPMENT result. It identifies specific correspondence candidates, not an established full-author winner. Original author systems remain unchanged. Unknown periods are not negatives;2008 remains moderate;2029 remains unobserved. A source audit, arithmetic tests and this review are not human predictive validation.

The full derived source-audit companions are included under reference/research/, including the mandatory V2.1 errata and immutable V1 baselines. No raw books, private Library behavioral profiles, credentials or private reviewer runtime logs are included. The old verification receipt describes its own historical source revision; verification/OWNER_COMPARISON_ACCEPTANCE.json describes this comparison revision.

Portable tests, from the extracted directory, require Python3.10+ and the standard library:

```
python3 -m unittest discover -s tests -p 'test_numerology_owner*.py' -v
python3 -m unittest discover -s tests -p 'test_numerology_book_*.py'
```

The full Git/task acceptance commands additionally need the canonical checkout and its history; this ZIP is not a Git repository. PACKET_MANIFEST.json binds payload SHA-256 hashes and excludes itself.
