# GPT builder configuration

Use these user-facing fields in the Custom GPT editor.

## Name

Life Patterns Interview

## Description

A private voice-or-text research interview with an independent quality-review step before the final record is frozen. You can pause, skip, correct, or resume. The interview does not ask for or use birth/chart information.

## Conversation starters

1. Start my Life Patterns interview.
2. Find my Life Patterns record in my Library and continue.
3. Continue my interview from this chat or a record I attach.
4. Check my independent Life Patterns review.

## Capabilities

Enable **Code Interpreter & Data Analysis** for downloadable backup JSON files.

## Action

Create one Action:
- Schema URL: `https://life-patterns-participant-production.up.railway.app/action-openapi.yaml`
- Authentication: **API key → Bearer**
- API key: use the private submission-only key supplied separately; never use the researcher/admin token.
- Privacy policy: `https://life-patterns-participant-production.up.railway.app/privacy`

The Action first queues the unfrozen, chart-blind primary record for independent study review, lets the GPT check status and submit any admitted clarification answer, and later sends the reviewed frozen primary plus CF-003 records to Joel's encrypted study store. During this development pilot the queued review may be processed through Joel's ChatGPT-authenticated Codex CLI. ChatGPT may require approval for external writes. Use an action-capable non-Pro model.

## Expected opening behavior

A Custom GPT cannot send a message before the user sends or taps something. When the participant taps a starter or sends any first message, the GPT Instructions require it to immediately:
- explain the research purpose, that responses may be shared with Joel, and that the chart-blind interview will receive an independent study-AI review before final freeze;
- say voice or text is fine and the participant may pause, skip, correct, or stop;
- say birth/chart information will not be requested or used;
- explain that Railway Action calls may show permission cards from `life-patterns-participant-production.up.railway.app`; immediately before each such call say exactly once **“Please click Allow on this tool call to continue.”** (the UI may label the button **Allow once**);
- request ONLY research-use consent covering independent review/final submission when needed; say “You are welcome to type or talk.” Do not ask mode or early-life setup questions; earlier-life comparisons default to welcome with skip/opt-out preserved;
- then begin without requiring another “ready” message.

For a participant with an existing interview, there are three safe resume paths:
- **Library fallback:** use starter 2. This explicitly authorizes a narrow Library search for canonical Life Patterns export/recovery schemas only. Search and compare actual source/provenance first. A unique verified successor or equivalent duplicate is selected automatically; only conflicting or unrelated lineages require participant selection. Never use a merely similar behavioral/interview file.
- **Same-chat automatic resume (web):** reopen the old interview, type `@`, select **Life Patterns Interview**, then say “Continue my interview.” The GPT uses only that conversation's visible interview context.
- **New-chat attachment:** explicitly attach/add the participant's interview record, then use starter 3.

A generic continue request must not search Library, Memory, chat history, connected apps, or other account-level sources.

Schema 1.2.3 adds review start, status, clarification, pause/stop/withdraw controls, strict reviewed submission, and `recommended_check_after_seconds` so the GPT can give a real check-back interval instead of asking participants to guess. Import the existing schema URL again; JSON OpenAPI is valid at that YAML endpoint. The same Bearer key remains valid. Treat review IDs as private.

## Historical delivery hotfix 2026-10-01.5 (superseded where noted below)

Add `ACTION-HANDOFF-GUIDE-v1.md` as the sixth Knowledge file. Replace Instructions and reimport the existing Action schema (1.2.1); keep the same Bearer credential. This adds exact backup before the first review call, actionable error paths, the explicit approval sentence, honest stage/count progress, and a bottom status footer. Existing five Knowledge files and frozen v7 measurement wording are unchanged. A separate hybrid question candidate is under development; this delivery fix does not silently activate it.

## Owner testing / GPT updates

Use Builder Preview only for short smoke tests. For any interview whose answers matter, open the GPT as a normal saved conversation.

**Before clicking Update while an interview is in progress:** in that interview chat, ask: `Create my Life Patterns recovery checkpoint before I update the GPT.` Wait for the actual `life-patterns-live-recovery-checkpoint.json` file link and verify the GPT reports the correct answer count. Only then edit/update the GPT. After an update, reopen the same saved conversation if available; otherwise attach the checkpoint or explicitly use the canonical Library fallback. Never interpret a new chat with zero visible turns as proof that the old answers never existed.

## Owner hotfix 2026-10-02.2

Before the first review call, preserve both the exact candidate backup and `life-patterns-review-handoff.json`, which contains the exact three-field request envelope and durable `request_id`. After a successful queue, preserve the returned review handle in a private transport receipt when possible. If the handle is later missing, replay the exact saved start-review request so server idempotency returns the existing review; never mint a new ID merely to recover state.


## Owner hotfix 2026-10-03.1

After a review start or clarification answer queues a remote pass, use `recommended_check_after_seconds`. Current measured fallback is about **10 minutes** for the initial pass and **3 minutes** after a clarification. Participants do not need to keep the chat open; “continue,” “check,” or “I'm back” checks the same saved review automatically. Do not impose an arbitrary clarification-count cap: another question is allowed only when independently admitted as materially useful and nonredundant.

Do not promise a proactive notification from the current Custom GPT. Scheduled tasks do not run inside GPTs, so the current GPT cannot wake itself or notify the participant when Railway finishes. The plugin migration should evaluate an event/notification path separately rather than hiding this limitation behind repeated manual polling.

## Fast review update — 2026-10-05

Update the existing GPT, not a new GPT. Replace Instructions, the Action schema, and ACTION-HANDOFF-GUIDE-v1.md in Knowledge using the new fast-review bundle. Keep the same Bearer credential and the other five Knowledge files unchanged. New requests use fast-batch-v1; existing review request envelopes remain unchanged on recovery. The server returns individual stage ranges and check-back guidance; first questions and final evidence review are separate. Independent batch questions are asked one at a time locally and answered in one Action. No fixed lifetime clarification cap is introduced.

## Current collection correction — 2026-10-06

Replace Instructions and BOTH Knowledge guides: RECOVERY-GUIDE-v2.md and ACTION-HANDOFF-GUIDE-v1.md. Keep the four scientific/reference Knowledge files, Action schema and Bearer credential unchanged. The opening has only the research consent question, never a mode selector or earlier-life opt-in question. Default is study-default welcome, not fabricated express permission; explicit opt-outs win. Mode metadata remains unknown unless actually supported.

Progress now includes the provisional remaining questions AND answering minutes to independent review, grounded in the current revisable plan. A count/topic footer alone is not progress. Recovery searches all canonical schemas/aliases and compares duplicates and successors before selecting. A historically complete imported record goes straight to independent review, not a new local interview. These Instructions override old collection/setup wording in historical examples; frozen question and evidence semantics are unchanged.

## Active tendency-first elicitation — 2026-10-06

Add `TENDENCY-FIRST-GUIDE-v1.json` as the seventh Knowledge file and replace Instructions. The six existing Knowledge files, Action and credential remain. New selection uses the versioned TF1 usual-pattern questions, with examples only when needed. The frozen v7 bank is historical source/probe authority, not a mandate to role-play retired scenarios. The earlier draft-only wording status is superseded for this policy.
