# Update the installed GPT: progress and recoverable review requests

1. Replace Instructions with INSTRUCTIONS-life-patterns-voice-interviewer-v2.md.
2. Add knowledge/ACTION-HANDOFF-GUIDE-v1.md as the SIXTH Knowledge file. Keep the previous five files.
3. Reimport ACTION-life-patterns-submission-openapi.yaml into the EXISTING Action. Same URL, same Bearer credential; no second Action.
4. Keep Code Interpreter & Data Analysis enabled; save/update the GPT.

Before submitting, the GPT must now create and link the exact unfrozen candidate backup, construct the correct three-field JSON envelope, and say: “Please click accept on this tool call to submit your results for analysis.”

A rejected request must produce both the preserved candidate backup and a safe diagnostic artifact. New server validation responses name the field/type without echoing private answers. A past generic error does not reveal which field was rejected.

Questions gain an honest stage/count footer. This also moves the question above the native down-arrow area; it does not change ChatGPT CSS or prove that the native button is fixed. No fabricated percentage, question quota, or time guarantee.

For an existing completed interview, read all usable prior answers first. Do not repeat a distinction merely because a prompt was reworded. The separately supplied hybrid question trial/audit is a development candidate, NOT silently substituted for frozen v7. This hotfix does not require another full interview.

To recover the current failed attempt, paste:
“Do not ask more interview questions. Preserve every existing imported answer and new answer from this chat with its original wording and corrections. Follow ACTION-HANDOFF-GUIDE-v1.md: create and link my unfrozen candidate backup, then show me the error diagnostic if one is available. Only then rebuild the valid start-review envelope and ask me to approve submission. Do not claim missing source text was recovered.”
