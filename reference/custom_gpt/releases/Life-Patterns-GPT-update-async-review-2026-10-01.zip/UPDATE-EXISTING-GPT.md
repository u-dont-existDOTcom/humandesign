# Update your existing Life Patterns GPT

This packet updates the GPT you already installed. Keep its existing five Knowledge files and its existing API-key/Bearer credential.

1. Replace the GPT's Instructions with the complete contents of INSTRUCTIONS-life-patterns-voice-interviewer-v2.md.
2. In Actions, reimport the existing schema URL or paste ACTION-life-patterns-submission-openapi.yaml. It contains valid JSON-formatted OpenAPI. Keep API key -> Bearer and the same key. Do not create a second duplicate Action.
3. Copy the Description and Conversation starters from GPT-BUILDER-CONFIG.md. The fourth starter is now: Check my independent Life Patterns review.
4. Keep Code Interpreter & Data Analysis enabled and save/update the GPT.

The backend and local review worker are deployed separately. The participant's next interview uses this sequence:
collect exact source -> queue an unfrozen candidate -> check review later -> ask any exact admitted clarification -> independent neutral review -> primary freeze -> three CF-003 questions -> final submission.

Queued work does not require the chat to remain open. The local review worker needs the researcher's computer online. The GPT does not wake itself later; return to the same chat and ask it to check the review. Keep the review ID private.

For your own test, attach your completed source-only interview record, not the older checkpoint containing hidden model interpretation. The GPT must preserve usable answers rather than restart or pretend it read a file that is absent.

No Knowledge-file change or new participant API key is required. This is a development pilot, not a prospectively validated scientific instrument. The full bundle remains available in the humandesign repository and the researcher's Downloads folder.
