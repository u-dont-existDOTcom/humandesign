# Update the installed GPT: Action approvals + durable review recovery

1. Replace Instructions with INSTRUCTIONS-life-patterns-voice-interviewer-v2.md.
2. Replace the existing Knowledge file ACTION-HANDOFF-GUIDE-v1.md with knowledge/ACTION-HANDOFF-GUIDE-v1.md. Keep the other five Knowledge files unchanged.
3. Keep the EXISTING Action, schema URL and Bearer credential unchanged; this hotfix does not require a Railway/API change.
4. Keep Code Interpreter & Data Analysis enabled; save/update the GPT.

Before setup answers, the GPT now explains that ChatGPT will later show permission cards for the Life Patterns Railway service. Participants should choose **Allow once** for each step they want to continue. Several approvals can appear because review queue/check/clarification/final submission are separate external calls; the GPT must not promise an exact count.

Before queueing, the GPT now creates BOTH:
- `life-patterns-candidate-backup.json` — exact unfrozen candidate.
- `life-patterns-review-handoff.json` — exact three-field start-review request, including durable `request_id`.

After a successful queue it also preserves transport metadata in `life-patterns-review-receipt.json` when file creation is available.

If a later turn loses `review_id`, it must NOT create a new review. It reloads the saved review handoff and replays the exact same start request. Railway idempotency returns the existing review and handle (`duplicate: true`), after which the GPT can check the existing review normally.

This hotfix does not change frozen v7 question wording, the independent-review semantics, CF-003 ordering, or the Action API schema.
