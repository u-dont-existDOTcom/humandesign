# Update the installed GPT: review wait + approval UX

1. Replace Instructions with INSTRUCTIONS-life-patterns-voice-interviewer-v2.md.
2. Replace ACTION-HANDOFF-GUIDE-v1.md in Knowledge.
3. Replace GPT-BUILDER-CONFIG.md only as owner setup documentation; it is not a Knowledge file.
4. Reimport ACTION-life-patterns-submission-openapi.yaml into the EXISTING Action. Keep the same schema URL and Bearer credential; do not create a second Action.
5. Keep Code Interpreter & Data Analysis enabled; save/update the GPT.

Participant-facing changes:
- The approval sentence is exactly: “Please click Allow on this tool call to continue.”
- Say it once per Action call only. The UI may label the button “Allow once.”
- New review and clarification passes expose recommended_check_after_seconds. Current pilot runs commonly take about 10–15 minutes and can take longer.
- After a queued pass, tell the participant they can leave the chat and return in about 15 minutes. Any ordinary continuation message should check the same saved review automatically.
- After a clarification answer is submitted, explicitly say a new remote review pass is running; do not imply the next question/result should appear immediately.

This bundle includes the prior context-budget, retry-budget, item-level admission, and durable review-handoff repairs. It does not change frozen v7 question wording, primary/CF-003 ordering, or the participant's source record.
