# Update the installed GPT: large-record review recovery

1. Replace Instructions with INSTRUCTIONS-life-patterns-voice-interviewer-v2.md.
2. Replace the existing Knowledge file ACTION-HANDOFF-GUIDE-v1.md with knowledge/ACTION-HANDOFF-GUIDE-v1.md. Keep the other five Knowledge files unchanged.
3. Reimport ACTION-life-patterns-submission-openapi.yaml into the EXISTING Action. Keep the same schema URL and Bearer credential; do not create a second Action.
4. Keep Code Interpreter & Data Analysis enabled; save/update the GPT.

This bundle includes the prior Action-approval and durable review-handoff repair. Before Railway Actions, the GPT explains the permission cards and that several per-step approvals can appear.

Large recovered records now keep every exact imported source turn while compacting only redundant admission-transport material. A `resource_limited / model_context_budget_exceeded` result remains pending, not complete. After the service-side repair is deployed, the GPT can `retry` the SAME saved review ID; it must not start a replacement review.

Before queueing, the GPT still creates `life-patterns-candidate-backup.json` and `life-patterns-review-handoff.json`; after queue success it preserves `life-patterns-review-receipt.json` when possible.

Frozen v7 question wording, source evidence semantics, independent admission, and CF-003 ordering are unchanged.
