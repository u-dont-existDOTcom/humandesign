# Update the installed GPT: read-only status approval + review UX

1. Replace Instructions with INSTRUCTIONS-life-patterns-voice-interviewer-v2.md.
2. Replace ACTION-HANDOFF-GUIDE-v1.md in Knowledge.
3. Replace GPT-BUILDER-CONFIG.md only as owner setup documentation; it is not a Knowledge file.
4. Reimport ACTION-life-patterns-submission-openapi.yaml into the EXISTING Action. Keep the same schema URL and Bearer credential; do not create a second Action.
5. Keep Code Interpreter & Data Analysis enabled; save/update the GPT.

Participant-facing changes:
- The read-only review-status GET is explicitly marked nonconsequential. On accounts/surfaces where ChatGPT offers persistent approval for eligible low-risk actions, this can reduce repeated approval prompts for status checks.
- All participant-data/state-changing POST actions remain consequential and still require the platform's normal approval behavior.
- The approval sentence is exactly: “Please click Allow on this tool call to continue.”
- Say it once per Action call only. The UI may label the button “Allow once.”
- Review status exposes recommended_check_after_seconds. Current measured fallback is about 10 minutes for the initial pass and about 3 minutes after a clarification.
- Participants may leave the chat; any ordinary continuation message should check the same saved review automatically.
- The assistant-added one-clarification cap is removed. Another clarification is allowed only when the independent reviewer finds it admissible, nonredundant and materially useful; coverage alone is not enough.

This bundle includes the prior context-budget, retry-budget, item-level admission, and durable review-handoff repairs. It does not change frozen v7 question wording, primary/CF-003 ordering, or the participant's source record.
