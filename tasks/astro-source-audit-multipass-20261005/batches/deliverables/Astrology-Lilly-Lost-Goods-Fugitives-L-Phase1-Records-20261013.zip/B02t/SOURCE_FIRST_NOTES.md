# Lilly B02t Phase 1 original-image-first notes (NOT yet accepted)

Verified source: William Lilly (1647) Wellcome b30338724, full 894-page scan SHA256 `2cb53e20e122ffc6e47917ba10241f6c49687cd7a4696f3b5db655a2a1aab28b`.

Read original full Chapter L boundary: PDF353/printed319 **below** marriage XLIX divider through PDF400/printed366 **above** LI divider. Phase1 only PDF353 lower to PDF364 upper, before independent `Of a Thief and Theft` heading. Phase2 begins below that heading on same PDF364; DO NOT count heading itself as evidence of theft. PDF365–369 and PDF400 included only for context, not extracted phase1 content.

All 19 page/errata source PNGs have byte manifests and pixel replay. Source draft 129 units R2138–R2266; all provisional, zero observed cases or verified life outcomes. The 129 code labels are editor-created, not printed aphorism numbers.

Opening Moon/house and lunar ruler recovery; how lost by ascendant-lord last separation; strayed vs stolen beast, eighth-house death/custody, first/second/6th/12th lord alternatives; Moon and sign-direction house/place rules; `Of Beasts or Strayes` original PDF358; `Another Judgment` original PDF359; terrain, pounds, cattle escape; human fugitive capture and return original PDF362–364; source distance estimates: movable **17**, common **5**, fixed **1** houses/furlongs per degree, source prefers lunar distance over seventh-hour distance; `Of a Woman flying from her Husband` immediately precedes next thief heading.

Original-volume errata PDF888 has selective entries printed p324 line10 `read the`, p330 line6 `read or`. Exact body line targets unknown: retain original images unchanged and keep correction orders separately. Other glyphs and marginal handwriting not authorially authenticated.

Ambiguous ancient vocabulary (pound = animal pen, not money or weight); authors’ conjectures not modern evidence concerning theft, criminal guilt, animal health, captivity, safety or factual motive. The complete Chapter L contains later sections beyond phase1, so DO NOT advance `read_numbered_chapters` to 50 until final phase accepted. Independent Opus reviewers A/B were staged without producer notes and each reads original image first. Wait for actual review files, reconcile material findings, then run tests, archive and stage-specific publication.

## 2026-10-13 first independent original-image reviews, source repair

- Fresh original-image window A reviewed PDF353–359 and 70 draft records, 7 major and 15 moderate material findings; window B reviewed PDF359–364 and 71 records, 9 high and 18 medium findings. The original initial outputs are retained and hash-checked.
- Restored the Moon-derived eighth from the Moon, radical eighth fallback, p325 second/FIFTH/eleventh recovery, p330 'OR' erratum, opposite news/regret lunar directions, and all B-reported additional headings/conditional units.
- The next physical PDF364 contains some phase1 body then the separate thief-and-theft heading opening phase2; do not count a source paragraph in both phases.
- Phase1 after repairs holds 162 reference-only normalized source units; all Chapter L beyond the p330 thief divider remains untouched and OPEN.

## Post-correction fresh source readers

Reader A/B were frozen new-context source-image-first reviews; both found further errors in the 162-record candidate. Controller repairs include Moon-derived eighth, lunar news direction, heavy pound/custody source conditions, printed p330 'read or', and six recovered source clauses. The corrected source inventory is 168 records, with 56 retained limitations. No third final blind rereview; no empirical validation.
