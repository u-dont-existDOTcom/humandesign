# Lilly wealth audit: complete source packet

Open B02g/REPORT.md for the findings and B02g/CONVERSATION_HANDOFF.md for the next source action. The complete normalized records, evidence, reviews and bounded calculation code are in B02g. The unchanged B02f geometry companion required by these checks is included.

From this extracted directory, reproduce the 28 new tests with:

```sh
python3 -m unittest discover -s B02g -p 'test_lilly_wealth*.py' -v
```

Python 3.12 was used for the delivered check; this command needs only the standard library. The original 121-test focused run includes 93 retained checks from the full research repository. Those retained suites are not all replicated in this standalone packet.

DISTRIBUTION_PROVENANCE.json identifies the exact published source revision and maps repository-relative source-manifest paths to this packet. PACKET_CONTENTS.json hashes all other archive members. Neither manifest contains its own hash. Publication is established in B02g/PUBLICATION_RECEIPT.json; later actual archive distribution and owner delivery receipts are outside this immutable ZIP to avoid a self-reference cycle.

The original PDF, full text and page images remain outside this archive. The reading receipt and handoff identify the source witness and hash. This is historical source research and static arithmetic, with no claim of predictive validation.

Next: the third-house heading and entire preamble below the divider on PDF 221 / printed 187, then Chapter XXIX on PDF 222 / printed 188.
