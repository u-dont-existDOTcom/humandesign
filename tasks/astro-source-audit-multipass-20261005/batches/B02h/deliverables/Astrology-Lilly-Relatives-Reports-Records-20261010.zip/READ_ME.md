# Lilly third-house packet

Start with B02h/AUDIT_REPORT.md and B02h/README.md. Run python3 verify_packet.py, then the 24-test B02h suite documented there.

Evidence ledgers preserve source-repository paths. The included Lilly and Ptolemy index snapshots and dated continuation state are under context/. The required earlier geometry helper is under B02f/. This packet contains the complete new batch and its declared companions, not every earlier source record.
