from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'PACKET_CONTENTS.json').read_text())
for row in m['files']:
    p=root/row['path']
    assert p.is_file(),str(p)
    assert len(p.read_bytes())==row['bytes'],str(p)
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],str(p)
print(json.dumps({'status':'PASS','verified_files':len(m['files'])}))
