# Lilly fourth-house packet

Start with `B02i/AUDIT_REPORT.md` and `B02i/README.md`.

From this packet root run:

```bash
python3 verify_packet.py
python3 -B -m unittest discover -s B02i -p 'test_*.py' -v
```

The supported standalone new suite has 29 tests and uses the Python standard library. The reported repository-wide focused subset has 111 distinct tests, including 82 retained tests whose projects are not duplicated wholesale here. Source-stage test receipts are included; actual extracted-packet execution has its own later receipt.

Both source-index snapshots and the dated continuation state are under `context/`. The required unchanged helper is under `B02f/`. The complete new batch and declared comparison companions are included; the whole cumulative corpus and retained original PDF are not. Evidence ledgers retain source-repository paths as provenance.

The next reading begins with the fifth-house heading and Chapter XXXIX below the divider on PDF256 / printed222, including the opening paragraph. Source completion, remote-source publication, archive verification and owner delivery are distinct stages. These materials do not establish predictive accuracy.
