"""Verify the files listed in this packet's content manifest."""
from pathlib import Path, PurePosixPath
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / "PACKET_CONTENTS.json").read_text())
seen = set()
for row in manifest["files"]:
    relative = PurePosixPath(row["path"])
    if relative.is_absolute() or ".." in relative.parts or str(relative) in seen:
        raise ValueError("Invalid or duplicate packet path: " + str(relative))
    seen.add(str(relative))
    path = root.joinpath(*relative.parts)
    if not path.is_file():
        raise FileNotFoundError(path)
    data = path.read_bytes()
    if len(data) != row["bytes"]:
        raise ValueError("Byte count differs: " + str(relative))
    if hashlib.sha256(data).hexdigest() != row["sha256"]:
        raise ValueError("SHA256 differs: " + str(relative))
print(json.dumps({"status": "PASS", "verified_files": len(seen),
                  "source_revision": manifest["source_revision"],
                  "verification_scope": "Listed packet bytes only; not predictive accuracy or owner delivery"}))
